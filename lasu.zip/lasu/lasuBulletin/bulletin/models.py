from django.db import models
from django.utils import timezone
from django.urls import reverse
# Create your models here.
class Post(models.Model):
    sender = models.CharField(max_length=250)
    receiver = models.CharField(max_length=250)
    ref = models.CharField(max_length=250)
    date = models.DateField(default=timezone.now)
    title = models.CharField(max_length=100)
    content = models.TextField()
    def __str__(self):
        return self.title
    def get_absolute_url(self):
        return reverse('post_detail', args=[str(self.id)])