from django.urls import path
from .views import BulletinListView,BulletinDetailView,BulletinCreateView,BulletinUpdateView,BulletinDeleteView,landingPage
urlpatterns = [
    path('post/<int:pk>/delete/', BulletinDeleteView.as_view(), name='post_delete'),
    path('post/<int:pk>/edit/', BulletinUpdateView.as_view(), name='post_edit'),
    path('post/new/', BulletinCreateView.as_view(), name='post_new'),
    path('post/<int:pk>/', BulletinDetailView.as_view(), name='post_detail'),
    path('home/', BulletinListView.as_view(), name='home'),
    path('',landingPage.as_view(),name = 'landing')
    ]